package com.example.appgym

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
