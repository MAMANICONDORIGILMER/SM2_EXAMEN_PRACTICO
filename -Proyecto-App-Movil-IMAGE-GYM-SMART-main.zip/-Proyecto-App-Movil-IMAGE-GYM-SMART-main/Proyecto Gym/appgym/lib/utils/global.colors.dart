import 'package:hexcolor/hexcolor.dart';

class GlobalColor {
  static HexColor mainColor = HexColor('#1E3190');
  static HexColor textColor = HexColor('#4F4F4F');
}
